const cards = [
  {
    img:"https://images.unsplash.com/photo-1543589077-47d81606c1bf?auto=format&fit=crop&w=800&q=80",
    no:"juletre",
    th:"ต้นคริสต์มาส",
    cat:"🎄 Xmas",
    num:1,
    sentence:"Vi pynter juletreet sammen i stua.",
    th_sentence:"เราตกแต่งต้นคริสต์มาสด้วยกันในห้องนั่งเล่น",
    read:"วี พุนแตร์ ยูเลทเรเอ ซัมเมิน อี สตูอา"
  },
  {
    img:"https://images.unsplash.com/photo-1607082349566-187t46a3665f?auto=format&fit=crop&w=800&q=80",
    no:"julegaver",
    th:"ของขวัญคริสต์มาส",
    cat:"🎄 Xmas",
    num:2,
    sentence:"Barna gleder seg til å åpne julegaver.",
    th_sentence:"เด็กๆ ตื่นเต้นที่จะเปิดของขวัญคริสต์มาส",
    read:"บาร์นา เกลเดอร์ ไช ทิล ออ ออพเน ยูเลกาวแวร์"
  },
  {
    img:"https://images.unsplash.com/photo-1544207240-42875e0e75aa?auto=format&fit=crop&w=800&q=80",
    no:"julemiddag",
    th:"อาหารเย็นวันคริสต์มาส",
    cat:"🎄 Xmas",
    num:3,
    sentence:"Hele familien samles til julemiddag.",
    th_sentence:"ทั้งครอบครัวมารวมตัวกันเพื่ออาหารเย็นวันคริสต์มาส",
    read:"เฮเล ฟามีเลียน ซัมเลส ทิล ยูเลมิดดาก"
  },
  {
    img:"https://images.unsplash.com/photo-1604908177072-e89dfbf2df75?auto=format&fit=crop&w=800&q=80",
    no:"ribbe",
    th:"ซี่โครงหมูอบ",
    cat:"🎄 Xmas",
    num:4,
    sentence:"Vi spiser ribbe på julaften.",
    th_sentence:"เรากินซี่โครงหมูอบในคืนคริสต์มาสอีฟ",
    read:"วี สปีเซร์ ริบเบะ โป ยูลาฟเทน"
  },
  {
    img:"https://images.unsplash.com/photo-1605476449275-3bd6c3a1e9b4?auto=format&fit=crop&w=800&q=80",
    no:"pinnekjøtt",
    th:"ซี่โครงแกะเค็ม",
    cat:"🎄 Xmas",
    num:5,
    sentence:"I noen familier er pinnekjøtt tradisjon.",
    th_sentence:"ในบางครอบครัว pinnekjøtt เป็นธรรมเนียมประจำคริสต์มาส",
    read:"อี นูเอน ฟามีลิเยร์ แอร์ พินเนอเคิท ทราดิตชั่น"
  },
  {
    img:"https://images.unsplash.com/photo-1603133872878-684f5f6c6714?auto=format&fit=crop&w=800&q=80",
    no:"julegrøt",
    th:"โจ๊กข้าวคริสต์มาส",
    cat:"🎄 Xmas",
    num:6,
    sentence:"Barna liker å få mandel i julegrøten.",
    th_sentence:"เด็กๆ ชอบได้อัลมอนด์ในโจ๊กคริสต์มาส",
    read:"บาร์นา ลีเคร์ ออ โฟ มันเดล อี ยูเลเกริต"
  },
  {
    img:"https://images.unsplash.com/photo-1544964705-e3d46d2b5f31?auto=format&fit=crop&w=800&q=80",
    no:"julelys",
    th:"ไฟประดับคริสต์มาส",
    cat:"🎄 Xmas",
    num:7,
    sentence:"Vi tenner julelys i vinduene.",
    th_sentence:"เรา点ไฟประดับคริสต์มาสที่หน้าต่าง",
    read:"วี เท็นเนอร์ ยูเลลิส อี วินดูเเน"
  },
  {
    img:"https://images.unsplash.com/photo-1575831024644-fd2aafb48994?auto=format&fit=crop&w=800&q=80",
    no:"nisse",
    th:"ภูติ/ซานต้าน้อย",
    cat:"🎄 Xmas",
    num:8,
    sentence:"Barna håper at nissen kommer med gaver.",
    th_sentence:"เด็กๆ หวังว่า Nissen จะมาพร้อมของขวัญ",
    read:"บาร์นา โฮเปร์ อัท นิสเซน คอมเมอร์ เมด กาเวอร์"
  },
  {
    img:"https://images.unsplash.com/photo-1606664515524-3ad72037efa1?auto=format&fit=crop&w=800&q=80",
    no:"julekaker",
    th:"คุกกี้คริสต์มาส",
    cat:"🎄 Xmas",
    num:9,
    sentence:"Vi baker julekaker hele desember.",
    th_sentence:"เราทำคุกกี้คริสต์มาสตลอดทั้งเดือนธันวาคม",
    read:"วี บาเคอร์ ยูเลคาเคอร์ เฮเล เดเซมเบอร์"
  },
  {
    img:"https://images.unsplash.com/photo-1606787364406-a3cdf06c6d0c?auto=format&fit=crop&w=800&q=80",
    no:"familie",
    th:"ครอบครัว",
    cat:"🎄 Xmas",
    num:10,
    sentence:"Det viktigste i julen er å være sammen med familien.",
    th_sentence:"สิ่งสำคัญที่สุดในคริสต์มาสคือได้อยู่กับครอบครัว",
    read:"เด วิกติเกิสเต อี ยูเลน แอร์ ออ แวเร ซัมเมิน เมด ฟามีเลียน"
  }
];

let norwegianVoice = null;
function loadVoices(){
  const v = speechSynthesis.getVoices();
  norwegianVoice = v.find(x =>
    x.lang.toLowerCase().startsWith("nb") ||
    x.lang.toLowerCase().startsWith("no")
  ) || null;
}
speechSynthesis.onvoiceschanged = loadVoices;
loadVoices();

function randomCard(){
  const c = cards[Math.floor(Math.random()*cards.length)];

  document.getElementById("cardImg").src = c.img;
  document.getElementById("word").textContent = c.no;
  document.getElementById("meaning").textContent = c.th;
  document.getElementById("category").textContent = c.cat;
  document.getElementById("number").textContent = c.num;

  document.getElementById("sentence").textContent = c.sentence;
  document.getElementById("sentence-th").textContent = c.th_sentence;
  document.getElementById("sentence-read").textContent = c.read;
}

function speakWord(){
  speak(document.getElementById("word").textContent);
}

function speakSentence(){
  speak(document.getElementById("sentence").textContent);
}

function speak(txt){
  const u = new SpeechSynthesisUtterance(txt);
  u.lang = norwegianVoice ? norwegianVoice.lang : "nb-NO";
  if(norwegianVoice) u.voice = norwegianVoice;
  u.rate = 0.9;
  speechSynthesis.cancel();
  speechSynthesis.speak(u);
}
